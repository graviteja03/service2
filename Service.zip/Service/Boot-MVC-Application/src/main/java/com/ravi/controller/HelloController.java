package com.ravi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HelloController {
	
	@GetMapping("/hello")
	public String helloMethod(Model model)
	{
		model.addAttribute("message", "welcome to spring-boot mvc");
		return "hello";
	}

}
