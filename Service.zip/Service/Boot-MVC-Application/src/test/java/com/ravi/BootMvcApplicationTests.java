package com.ravi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
